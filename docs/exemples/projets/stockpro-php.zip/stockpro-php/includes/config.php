<?php
// Connexion à la base de données
$db_host = "localhost";
$db_user = "stockpro";
$db_password = "Stock2015!";
define('UPLOAD_DIR', '/var/www/stockpro/uploads/');

$link = mysql_connect($db_host, $db_user, $db_password);
mysql_select_db("stockpro", $link);
