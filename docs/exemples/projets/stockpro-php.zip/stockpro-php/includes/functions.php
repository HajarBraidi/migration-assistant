<?php
function get_produits($categorie) {
    $categorie = mysql_real_escape_string($categorie);
    $result = mysql_query("SELECT * FROM produits WHERE categorie = '$categorie'");
    $produits = array();
    while ($row = mysql_fetch_assoc($result)) {
        $produits[] = $row;
    }
    return $produits;
}

function code_valide($code) {
    return ereg("^[A-Z]{3}-[0-9]{4}$", $code);
}

function chiffrer($texte, $cle) {
    return mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $cle, $texte, MCRYPT_MODE_ECB);
}

function premiere_lettre($nom) {
    return $nom{0};
}

function afficher_options($options) {
    while (list($cle, $valeur) = each($options)) {
        echo "<option value='$cle'>$valeur</option>";
    }
}

function __autoload($classe) {
    require_once 'classes/' . $classe . '.php';
}
