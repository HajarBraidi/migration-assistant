<?php include '../includes/config.php'; include '../includes/functions.php'; ?>
<html>
<head><script src="../assets/js/jquery-1.11.min.js"></script></head>
<body>
<? $produits = get_produits($_GET['categorie']); ?>
<table>
<?php foreach ($produits as $p) { ?>
  <tr><td><?php echo $p['nom']; ?></td><td><?php echo $p['quantite']; ?></td></tr>
<?php } ?>
</table>
<script>$(document).ready(function () { $('table').addClass('liste'); });</script>
</body>
</html>
