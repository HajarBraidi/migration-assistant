<?php
include '../includes/config.php';
if (isset($_FILES['fichier'])) {
    move_uploaded_file($_FILES['fichier']['tmp_name'], UPLOAD_DIR . $_FILES['fichier']['name']);
    $lignes = split(";", file_get_contents(UPLOAD_DIR . $_FILES['fichier']['name']));
    echo "Import terminé : " . count($lignes) . " lignes.";
}
