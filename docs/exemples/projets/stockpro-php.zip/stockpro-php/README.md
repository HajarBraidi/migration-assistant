# StockPro

Gestion du stock des entrepôts : articles, fournisseurs et réapprovisionnement.
Application interne utilisée par 200 employés, installée sur un serveur dans nos locaux.
