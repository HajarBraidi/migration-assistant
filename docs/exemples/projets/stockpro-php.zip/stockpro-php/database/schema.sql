CREATE TABLE articles (id INT PRIMARY KEY, nom VARCHAR(100), quantite INT, entrepot_id INT);
CREATE TABLE fournisseurs (id INT PRIMARY KEY, nom VARCHAR(100), email VARCHAR(150), telephone VARCHAR(20));
CREATE TABLE entrepots (id INT PRIMARY KEY, ville VARCHAR(100));
