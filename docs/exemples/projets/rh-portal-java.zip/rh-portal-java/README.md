# RH-Portal

Portail des ressources humaines : congés, fiches de paie et dossiers des employés.

- Utilisé par environ 850 employés répartis sur 4 sites.
- Hébergé sur un serveur physique dans nos locaux (salle serveur du siège).
- Mise en production : 2019.
