CREATE TABLE employes (
  id NUMBER PRIMARY KEY,
  nom VARCHAR2(100),
  prenom VARCHAR2(100),
  email VARCHAR2(150),
  telephone VARCHAR2(20),
  date_naissance DATE,
  cin VARCHAR2(20),
  rib VARCHAR2(30),
  salaire NUMBER(10,2)
);

CREATE TABLE conges (
  id NUMBER PRIMARY KEY,
  employe_id NUMBER REFERENCES employes(id),
  date_debut DATE,
  date_fin DATE,
  statut VARCHAR2(20)
);
