package com.rhportal.service;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class CalculPaie {
    // Les formules de primes sont écrites en JavaScript par le service RH
    public double evaluer(String formule) throws Exception {
        ScriptEngine moteur = new ScriptEngineManager().getEngineByName("nashorn");
        return ((Number) moteur.eval(formule)).doubleValue();
    }
}
