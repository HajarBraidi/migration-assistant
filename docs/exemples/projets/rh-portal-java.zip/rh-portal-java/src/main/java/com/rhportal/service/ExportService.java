package com.rhportal.service;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.servlet.http.HttpServletResponse;
import sun.misc.BASE64Encoder;

public class ExportService {

    public String exporterXml(Object employe) throws Exception {
        JAXBContext contexte = JAXBContext.newInstance(employe.getClass());
        Marshaller marshaller = contexte.createMarshaller();
        java.io.StringWriter sortie = new java.io.StringWriter();
        marshaller.marshal(employe, sortie);
        return new BASE64Encoder().encode(sortie.toString().getBytes());
    }

    public Integer arrondir(double valeur) {
        return new Integer((int) Math.round(valeur));
    }
}
