const express = require('express');
const mysql = require('mysql');
const util = require('util');

const app = express();
const connexion = mysql.createConnection({
  host: '127.0.0.1',
  user: 'boutique',
  password: 'Boutique2018',
  database: 'boutique'
});

app.use('/produits', require('./routes/produits'));

app.listen(3000, () => console.log('Boutique démarrée'));

module.exports = { connexion, estListe: (x) => util.isArray(x) };
