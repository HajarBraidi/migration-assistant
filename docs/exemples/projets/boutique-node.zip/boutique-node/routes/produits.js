const express = require('express');
const multer = require('multer');
const request = require('request');
const url = require('url');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/image', upload.single('image'), (req, res) => {
  res.json({ fichier: req.file.filename });
});

router.get('/stock', (req, res) => {
  const parametres = url.parse(req.url, true).query;
  request('http://localhost:8080/stock?id=' + parametres.id, (err, r, corps) => res.send(corps));
});

module.exports = router;
