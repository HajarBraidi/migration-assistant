CREATE TABLE clients (id INT PRIMARY KEY, email VARCHAR(150), adresse VARCHAR(255), telephone VARCHAR(20));
CREATE TABLE commandes (id INT PRIMARY KEY, client_id INT, total DECIMAL(10,2), statut VARCHAR(20));
CREATE TABLE panier (id INT PRIMARY KEY, client_id INT, produit_id INT, quantite INT);
